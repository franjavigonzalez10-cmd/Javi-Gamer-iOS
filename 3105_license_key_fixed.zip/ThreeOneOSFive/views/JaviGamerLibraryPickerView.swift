import SwiftUI

struct JaviGamerLibraryPickerView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.dismiss) private var dismiss

    let onSelection: (URL) -> Void
    private let rootURL: URL?
    @State private var currentFolderURL: URL?

    init(onSelection: @escaping (URL) -> Void) {
        self.onSelection = onSelection
        let root = JaviGamerLibrary.rootURL()
        self.rootURL = root
        _currentFolderURL = State(initialValue: root)
    }

    var body: some View {
        NavigationStack {
            Group {
                if let folderURL = currentFolderURL {
                    libraryContents(folderURL)
                } else {
                    JaviGamerEmptyStateView(
                        title: language.text("javi_library.unavailable_title"),
                        systemImage: "shippingbox",
                        message: language.text("javi_library.unavailable_message")
                    )
                }
            }
            .navigationTitle(currentFolderURL?.lastPathComponent ?? "JAVI GAMER")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(language.text("common.cancel")) {
                        dismiss()
                    }
                }
            }
        }
    }

    @ViewBuilder
    private func libraryContents(_ folderURL: URL) -> some View {
        let items = JaviGamerLibrary.contents(of: folderURL)

        if items.isEmpty {
            JaviGamerEmptyStateView(
                title: language.text("javi_library.empty_title"),
                systemImage: "folder",
                message: language.text("javi_library.empty_message")
            )
        } else {
            List(items, id: \.self) { itemURL in
                let isDirectory = (try? itemURL.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false

                if isDirectory {
                    NavigationLink {
                        libraryContentsView(itemURL)
                    } label: {
                        row(for: itemURL, isDirectory: true)
                    }
                } else {
                    Button {
                        onSelection(itemURL)
                    } label: {
                        row(for: itemURL, isDirectory: false)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private func libraryContentsView(_ folderURL: URL) -> some View {
        JaviGamerLibraryFolderView(
            folderURL: folderURL,
            onSelection: onSelection
        )
        .environment(\.appLanguage, language)
    }

    private func row(for url: URL, isDirectory: Bool) -> some View {
        HStack(spacing: 12) {
            Image(systemName: isDirectory ? "folder.fill" : "doc.fill")
                .foregroundStyle(isDirectory ? AppTheme.accent : .secondary)
                .frame(width: 24)
            Text(url.lastPathComponent)
                .foregroundStyle(.primary)
                .lineLimit(2)
            Spacer(minLength: 8)
            if !isDirectory {
                Image(systemName: "checkmark.circle")
                    .foregroundStyle(AppTheme.accent)
            }
        }
        .contentShape(Rectangle())
        .padding(.vertical, 4)
    }
}

private struct JaviGamerEmptyStateView: View {
    let title: String
    let systemImage: String
    let message: String

    var body: some View {
        VStack(spacing: 10) {
            Image(systemName: systemImage)
                .font(.system(size: 42))
                .foregroundStyle(.secondary)
            Text(title)
                .font(.headline)
                .multilineTextAlignment(.center)
            Text(message)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(24)
    }
}

private struct JaviGamerLibraryFolderView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.dismiss) private var dismiss

    let folderURL: URL
    let onSelection: (URL) -> Void

    var body: some View {
        let items = JaviGamerLibrary.contents(of: folderURL)

        Group {
            if items.isEmpty {
                JaviGamerEmptyStateView(
                    title: language.text("javi_library.empty_title"),
                    systemImage: "folder",
                    message: language.text("javi_library.empty_message")
                )
            } else {
                List(items, id: \.self) { itemURL in
                    let isDirectory = (try? itemURL.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false

                    if isDirectory {
                        NavigationLink {
                            JaviGamerLibraryFolderView(
                                folderURL: itemURL,
                                onSelection: onSelection
                            )
                        } label: {
                            libraryRow(itemURL, isDirectory: true)
                        }
                    } else {
                        Button {
                            onSelection(itemURL)
                        } label: {
                            libraryRow(itemURL, isDirectory: false)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
        .navigationTitle(folderURL.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
    }

    private func libraryRow(_ url: URL, isDirectory: Bool) -> some View {
        HStack(spacing: 12) {
            Image(systemName: isDirectory ? "folder.fill" : "doc.fill")
                .foregroundStyle(isDirectory ? AppTheme.accent : .secondary)
                .frame(width: 24)
            Text(url.lastPathComponent)
                .foregroundStyle(.primary)
                .lineLimit(2)
            Spacer(minLength: 8)
            if !isDirectory {
                Image(systemName: "checkmark.circle")
                    .foregroundStyle(AppTheme.accent)
            }
        }
        .contentShape(Rectangle())
        .padding(.vertical, 4)
    }
}
