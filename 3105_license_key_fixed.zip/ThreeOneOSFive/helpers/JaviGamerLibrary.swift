import Foundation

/// Provides the read-only library bundled with the app.
/// The library is intentionally kept separate from patch projects and Documents.
enum JaviGamerLibrary {
    static let rootFolderName = "JaviGamerLibrary"
    static let filesFolderName = "Archivos"

    static func rootURL() -> URL? {
        Bundle.main.url(
            forResource: filesFolderName,
            withExtension: nil,
            subdirectory: rootFolderName
        )
    }

    static func contents(of folderURL: URL, fileManager: FileManager = .default) -> [URL] {
        guard let urls = try? fileManager.contentsOfDirectory(
            at: folderURL,
            includingPropertiesForKeys: [.isDirectoryKey, .isRegularFileKey, .isSymbolicLinkKey],
            options: [.skipsHiddenFiles]
        ) else {
            return []
        }

        return urls.filter { url in
            guard let values = try? url.resourceValues(
                forKeys: [.isDirectoryKey, .isRegularFileKey, .isSymbolicLinkKey]
            ) else { return false }
            return values.isSymbolicLink != true &&
                (values.isDirectory == true || values.isRegularFile == true)
        }.sorted { lhs, rhs in
            let lhsDirectory = (try? lhs.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            let rhsDirectory = (try? rhs.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            if lhsDirectory != rhsDirectory { return lhsDirectory }
            return lhs.lastPathComponent.localizedCaseInsensitiveCompare(rhs.lastPathComponent) == .orderedAscending
        }
    }
}
