import SwiftUI
import UIKit
import Security
import CryptoKit

@MainActor
final class LicenseGate: ObservableObject {
    enum State: Equatable {
        case locked
        case checking
        case unlocked
        case failed(String)
    }

    @Published private(set) var state: State = .locked
    @Published var key: String = ""
    @Published private(set) var expirationDate: Date?

    private let service = LicenseService()

    var isUnlocked: Bool { state == .unlocked }

    func validate() {
        let trimmed = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            state = .failed("Introduce una KEY.")
            return
        }

        state = .checking
        Task {
            do {
                try await service.activateIfNeeded(licenseKey: trimmed)
                let info = try await service.validate(licenseKey: trimmed)
                expirationDate = info.expiry
                try KeychainStore.set(trimmed, forKey: LicenseService.storageKey)
                state = .unlocked
            } catch {
                if let urlError = error as? URLError {
                    switch urlError.code {
                    case .notConnectedToInternet, .networkConnectionLost, .timedOut, .cannotConnectToHost, .cannotFindHost, .dnsLookupFailed, .secureConnectionFailed:
                        state = .failed(LicenseService.LicenseError.network.localizedDescription)
                    default:
                        state = .failed(LicenseService.LicenseError.network.localizedDescription)
                    }
                } else {
                    state = .failed(error.localizedDescription)
                }
            }
        }
    }

    func restoreStoredKey() {
        guard let stored = KeychainStore.string(forKey: LicenseService.storageKey), !stored.isEmpty else { return }
        key = stored
        validate()
    }

    func clear() {
        KeychainStore.delete(forKey: LicenseService.storageKey)
        KeychainStore.delete(forKey: LicenseService.machineIDKey)
        KeychainStore.delete(forKey: LicenseService.machineLicenseHashKey)
        key = ""
        expirationDate = nil
        state = .locked
    }
}

struct LicenseGateView: View {
    @Environment(\.appLanguage) private var language
    @ObservedObject var gate: LicenseGate

    var body: some View {
        ZStack {
            Color(.systemBackground).ignoresSafeArea()
            VStack(spacing: 20) {
                Spacer()
                Image(systemName: "key.fill")
                    .font(.system(size: 54))
                Text("Javi Gamer")
                    .font(.largeTitle.bold())
                Text("Licencia requerida")
                    .font(.headline)
                Text("Introduce tu KEY para continuar.")
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)

                SecureField("KEY de licencia", text: $gate.key)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)
                    .onSubmit { gate.validate() }

                Button {
                    gate.validate()
                } label: {
                    if case .checking = gate.state {
                        ProgressView().frame(maxWidth: .infinity)
                    } else {
                        Text("Activar").frame(maxWidth: .infinity)
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled({ if case .checking = gate.state { return true }; return false }())
                .padding(.horizontal)

                if case .failed(let message) = gate.state {
                    Text(message)
                        .font(.footnote)
                        .foregroundStyle(.red)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                }
                Spacer()
            }
            .padding()
        }
    }
}

struct LicenseService {
    static let storageKey = "JG.StoredLicenseKey"
    static let machineFingerprintKey = "JG.LicenseMachineFingerprint"
    static let machineIDKey = "JG.LicenseMachineID"
    static let machineLicenseHashKey = "JG.LicenseMachineHash"

    // Public identifiers from the Keygen dashboard. These are not secrets.
    private let accountID = "0523b281-7749-47fd-95f5-443cfedf5462"
    private let productID = "1ca70f95-263c-46ad-9afe-eeb0724cb837"
    private let policyID = "0ddff24e-5937-4e22-b71f-866eef6e37e7"

    private var apiBaseURL: URL {
        URL(string: "https://api.keygen.sh/v1/accounts/\(accountID)")!
    }

    enum LicenseError: LocalizedError {
        case invalidResponse
        case invalidKey
        case expired
        case suspended
        case revoked
        case deviceAlreadyUsed
        case wrongProductOrPolicy
        case activationRejected
        case deviceIdentityUnavailable
        case network

        var errorDescription: String? {
            switch self {
            case .invalidResponse:
                return "No se pudo verificar la licencia."
            case .invalidKey:
                return "La KEY no es válida."
            case .expired:
                return "La KEY ha expirado."
            case .suspended:
                return "La KEY está suspendida."
            case .revoked:
                return "La KEY ha sido revocada."
            case .deviceAlreadyUsed:
                return "Esta KEY ya está vinculada a otro dispositivo."
            case .wrongProductOrPolicy:
                return "Esta licencia no es válida para esta aplicación."
            case .activationRejected:
                return "No se pudo activar la KEY en este dispositivo."
            case .deviceIdentityUnavailable:
                return "No se pudo identificar este dispositivo."
            case .network:
                return "No se pudo verificar la licencia. Conéctate a Internet."
            }
        }
    }

    private func classifyDetail(_ detail: String) -> LicenseError? {
        let text = detail.lowercased()
        if text.contains("suspend") { return .suspended }
        if text.contains("expire") { return .expired }
        if text.contains("revok") { return .revoked }
        if text.contains("machine") || text.contains("device") || text.contains("activation") {
            if text.contains("exactly 1") || text.contains("already") || text.contains("maximum") || text.contains("limit") || text.contains("associated") {
                return .deviceAlreadyUsed
            }
        }
        if text.contains("invalid") || text.contains("not found") || text.contains("does not exist") || text.contains("revok") {
            return .invalidKey
        }
        return nil
    }

    private func classifyHTTP(status: Int, body: String) -> LicenseError {
        if let error = classifyDetail(body) { return error }
        switch status {
        case 401, 404:
            return .invalidKey
        case 409, 422:
            return .deviceAlreadyUsed
        case 408, 429, 500...599:
            return .network
        default:
            return .invalidResponse
        }
    }

    func validate(licenseKey: String) async throws -> LicenseInfo {
        let result = try await validateKey(licenseKey: licenseKey)
        guard result.valid else {
            throw classifyDetail(result.detail) ?? .invalidKey
        }
        return result
    }

    struct LicenseInfo {
        let licenseID: String
        let valid: Bool
        let detail: String
        let expiry: Date?
    }

    private func validateKey(licenseKey: String) async throws -> LicenseInfo {
        let url = apiBaseURL.appendingPathComponent("licenses/actions/validate-key")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("License \(licenseKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/vnd.api+json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/vnd.api+json", forHTTPHeaderField: "Accept")
        request.timeoutInterval = 15

        // Keygen requires a validation scope when the policy enforces a
        // machine limit. The fingerprint lets Keygen evaluate the license
        // against this specific device.
        if let fingerprint = deviceFingerprint() {
            request.httpBody = try JSONSerialization.data(withJSONObject: [
                "meta": [
                    "key": licenseKey,
                    "scope": [
                        "fingerprint": fingerprint
                    ]
                ]
            ])
        }

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw LicenseError.invalidResponse }
        let bodyText = String(data: data, encoding: .utf8) ?? ""
        guard (200...299).contains(http.statusCode) else {
            throw classifyHTTP(status: http.statusCode, body: bodyText)
        }

        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw LicenseError.invalidResponse
        }
        let dataObject = root["data"] as? [String: Any]
        let licenseID = (dataObject?["id"] as? String) ?? ""
        let attributes = dataObject?["attributes"] as? [String: Any]
        let expiry = Self.parseISO8601Date(attributes?["expiry"] as? String)
        let meta = root["meta"] as? [String: Any]
        let valid = (meta?["valid"] as? Bool) ?? false
        let detail = (meta?["detail"] as? String) ?? "License validation failed."

        if let relationships = dataObject?["relationships"] as? [String: Any],
           let policy = relationships["policy"] as? [String: Any],
           let policyData = policy["data"] as? [String: Any],
           let returnedPolicyID = policyData["id"] as? String,
           returnedPolicyID != policyID {
            throw LicenseError.wrongProductOrPolicy
        }

        guard !licenseID.isEmpty else { throw LicenseError.invalidResponse }
        return LicenseInfo(licenseID: licenseID, valid: valid, detail: detail, expiry: expiry)
    }

    private static func parseISO8601Date(_ value: String?) -> Date? {
        guard let value, !value.isEmpty else { return nil }
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = formatter.date(from: value) { return date }
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.date(from: value)
    }

    func activateIfNeeded(licenseKey: String) async throws {
        let licenseHash = sha256(licenseKey)
        if let machineID = KeychainStore.string(forKey: Self.machineIDKey),
           let storedHash = KeychainStore.string(forKey: Self.machineLicenseHashKey),
           !machineID.isEmpty, storedHash == licenseHash {
            return
        }

        if KeychainStore.string(forKey: Self.machineIDKey) != nil {
            KeychainStore.delete(forKey: Self.machineIDKey)
            KeychainStore.delete(forKey: Self.machineLicenseHashKey)
        }

        guard let fingerprint = deviceFingerprint() else {
            throw LicenseError.deviceIdentityUnavailable
        }

        // validate-key returns the license resource even when the policy is
        // waiting for its required machine association. We use that ID in the
        // JSON:API relationship required by POST /machines.
        let preflight = try await validateKey(licenseKey: licenseKey)
        guard !preflight.licenseID.isEmpty else { throw LicenseError.invalidResponse }
        if !preflight.valid {
            if let classified = classifyDetail(preflight.detail) {
                switch classified {
                case .expired, .suspended, .revoked, .invalidKey, .wrongProductOrPolicy:
                    throw classified
                default:
                    break
                }
            }
        }
        if preflight.valid { return }

        let url = apiBaseURL.appendingPathComponent("machines")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("License \(licenseKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/vnd.api+json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/vnd.api+json", forHTTPHeaderField: "Accept")
        request.timeoutInterval = 15

        let body: [String: Any] = [
            "data": [
                "type": "machines",
                "attributes": [
                    "fingerprint": fingerprint,
                    "name": "Power iPhone"
                ],
                "relationships": [
                    "license": [
                        "data": [
                            "type": "licenses",
                            "id": preflight.licenseID
                        ]
                    ]
                ]
            ]
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw LicenseError.invalidResponse }
        let bodyText = String(data: data, encoding: .utf8) ?? ""
        guard (200...299).contains(http.statusCode) else {
            throw classifyHTTP(status: http.statusCode, body: bodyText)
        }

        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let machineData = root["data"] as? [String: Any],
              let machineID = machineData["id"] as? String,
              !machineID.isEmpty else {
            throw LicenseError.invalidResponse
        }
        guard KeychainStore.set(machineID, forKey: Self.machineIDKey),
              KeychainStore.set(licenseHash, forKey: Self.machineLicenseHashKey) else {
            KeychainStore.delete(forKey: Self.machineIDKey)
            KeychainStore.delete(forKey: Self.machineLicenseHashKey)
            throw LicenseError.invalidResponse
        }
    }

    private func sha256(_ value: String) -> String {
        SHA256.hash(data: Data(value.utf8)).map { String(format: "%02x", $0) }.joined()
    }

    private func deviceFingerprint() -> String? {
        if let existing = KeychainStore.string(forKey: Self.machineFingerprintKey), !existing.isEmpty {
            return existing
        }

        let value = UUID().uuidString.lowercased()
        return KeychainStore.set(value, forKey: Self.machineFingerprintKey) ? value : nil
    }
}

private enum KeychainStore {
    static func string(forKey key: String) -> String? {
        var query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    @discardableResult
    static func set(_ value: String, forKey key: String) -> Bool {
        let data = Data(value.utf8)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key
        ]
        let attributes: [String: Any] = [
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        let status = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if status == errSecItemNotFound {
            var insert = query
            attributes.forEach { insert[$0.key] = $0.value }
            return SecItemAdd(insert as CFDictionary, nil) == errSecSuccess
        }
        return status == errSecSuccess
    }

    static func delete(forKey key: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key
        ]
        SecItemDelete(query as CFDictionary)
    }
}
