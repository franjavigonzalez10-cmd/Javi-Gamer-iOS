import SwiftUI
import UIKit
import Security
import CryptoKit

@MainActor
final class LicenseGate: ObservableObject {
    enum State: Equatable {
        case locked
        case checking
        case unlocked
        case failed(String)
    }

    @Published private(set) var state: State = .locked
    @Published var key: String = ""
    @Published private(set) var expirationDate: Date?

    private let service = LicenseService()

    var isUnlocked: Bool { state == .unlocked }

    func validate() {
        let trimmed = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            state = .failed("Introduce una KEY.")
            return
        }

        state = .checking
        Task {
            do {
                let info = try await service.validate(licenseKey: trimmed)
                expirationDate = info.expiry
                try KeychainStore.set(trimmed, forKey: LicenseService.storageKey)
                state = .unlocked
            } catch {
                if let urlError = error as? URLError {
                    switch urlError.code {
                    case .notConnectedToInternet, .networkConnectionLost, .timedOut, .cannotConnectToHost, .cannotFindHost, .dnsLookupFailed, .secureConnectionFailed:
                        state = .failed(LicenseService.LicenseError.network.localizedDescription)
                    default:
                        state = .failed(LicenseService.LicenseError.network.localizedDescription)
                    }
                } else {
                    state = .failed(error.localizedDescription)
                }
            }
        }
    }

    func restoreStoredKey() {
        guard let stored = KeychainStore.string(forKey: LicenseService.storageKey), !stored.isEmpty else { return }
        key = stored
        validate()
    }

    func clear() {
        KeychainStore.delete(forKey: LicenseService.storageKey)
        KeychainStore.delete(forKey: LicenseService.machineIDKey)
        KeychainStore.delete(forKey: LicenseService.machineLicenseHashKey)
        key = ""
        expirationDate = nil
        state = .locked
    }
}

struct LicenseGateView: View {
    @Environment(\.appLanguage) private var language
    @ObservedObject var gate: LicenseGate

    var body: some View {
        ZStack {
            Color(.systemBackground).ignoresSafeArea()
            VStack(spacing: 20) {
                Spacer()
                Image(systemName: "key.fill")
                    .font(.system(size: 54))
                Text("Javi Gamer")
                    .font(.largeTitle.bold())
                Text("Licencia requerida")
                    .font(.headline)
                Text("Introduce tu KEY para continuar.")
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)

                SecureField("KEY de licencia", text: $gate.key)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)
                    .onSubmit { gate.validate() }

                Button {
                    gate.validate()
                } label: {
                    if case .checking = gate.state {
                        ProgressView().frame(maxWidth: .infinity)
                    } else {
                        Text("Activar").frame(maxWidth: .infinity)
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled({ if case .checking = gate.state { return true }; return false }())
                .padding(.horizontal)

                if case .failed(let message) = gate.state {
                    Text(message)
                        .font(.footnote)
                        .foregroundStyle(.red)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                }
                Spacer()
            }
            .padding()
        }
    }
}

struct LicenseService {
    static let storageKey = "JG.StoredLicenseKey"
    static let machineFingerprintKey = "JG.LicenseMachineFingerprint"
    // Kept only so older installs can clean up the previous Keygen values.
    static let machineIDKey = "JG.LicenseMachineID"
    static let machineLicenseHashKey = "JG.LicenseMachineHash"

    private let validateURL = URL(string: "https://api.javigamer.com/api/validate")!

    enum LicenseError: LocalizedError {
        case invalidResponse
        case invalidKey
        case expired
        case suspended
        case revoked
        case deviceAlreadyUsed
        case maintenance
        case deviceIdentityUnavailable
        case network
        case serverMessage(String)

        var errorDescription: String? {
            switch self {
            case .invalidResponse:
                return "No se pudo verificar la licencia."
            case .invalidKey:
                return "La KEY no es válida."
            case .expired:
                return "La KEY ha expirado."
            case .suspended:
                return "La KEY está suspendida."
            case .revoked:
                return "La KEY ha sido revocada."
            case .deviceAlreadyUsed:
                return "Esta KEY ya está vinculada a otro dispositivo."
            case .maintenance:
                return "El sistema se encuentra en mantenimiento. Inténtalo nuevamente más tarde."
            case .deviceIdentityUnavailable:
                return "No se pudo identificar este dispositivo."
            case .network:
                return "No se pudo verificar la licencia. Conéctate a Internet."
            case .serverMessage(let message):
                return message
            }
        }
    }

    struct LicenseInfo {
        let valid: Bool
        let status: String
        let detail: String
        let expiry: Date?
        let remainingSeconds: Int?
    }

    func validate(licenseKey: String) async throws -> LicenseInfo {
        guard let deviceID = deviceFingerprint() else {
            throw LicenseError.deviceIdentityUnavailable
        }

        var request = URLRequest(url: validateURL)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.timeoutInterval = 15

        let payload: [String: Any] = [
            "key": licenseKey,
            "device_id": deviceID,
            "device_name": UIDevice.current.name
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: payload)

        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await URLSession.shared.data(for: request)
        } catch {
            throw LicenseError.network
        }

        guard let http = response as? HTTPURLResponse else {
            throw LicenseError.invalidResponse
        }

        guard let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            if (500...599).contains(http.statusCode) { throw LicenseError.network }
            throw LicenseError.invalidResponse
        }

        let valid = root["valid"] as? Bool ?? false
        let status = (root["status"] as? String ?? "").lowercased()
        let message = (root["message"] as? String)
            ?? (root["detail"] as? String)
            ?? "No se pudo verificar la licencia."
        let expiry = Self.parseISO8601Date(root["expires_at"] as? String)
        let remaining = Self.intValue(root["remaining_seconds"])

        guard (200...299).contains(http.statusCode) else {
            throw error(for: status, message: message, httpStatus: http.statusCode)
        }

        guard valid else {
            throw error(for: status, message: message, httpStatus: http.statusCode)
        }

        return LicenseInfo(
            valid: true,
            status: status,
            detail: message,
            expiry: expiry,
            remainingSeconds: remaining
        )
    }

    private func error(for status: String, message: String, httpStatus: Int) -> LicenseError {
        let text = (status + " " + message).lowercased()
        if text.contains("maintenance") || text.contains("mantenimiento") { return .maintenance }
        if text.contains("antishare") || text.contains("device") || text.contains("dispositivo") { return .deviceAlreadyUsed }
        if text.contains("suspend") || text.contains("pausad") { return .suspended }
        if text.contains("revok") || text.contains("revoc") { return .revoked }
        if text.contains("expir") || text.contains("venc") { return .expired }
        if text.contains("invalid") || text.contains("inválid") || text.contains("invalida") || httpStatus == 404 { return .invalidKey }
        if httpStatus == 408 || httpStatus == 429 || (500...599).contains(httpStatus) { return .network }
        return message.isEmpty ? .invalidResponse : .serverMessage(message)
    }

    private static func intValue(_ value: Any?) -> Int? {
        if let value = value as? Int { return value }
        if let value = value as? Int64 { return Int(value) }
        if let value = value as? Double { return Int(value) }
        if let value = value as? NSNumber { return value.intValue }
        if let value = value as? String { return Int(value) }
        return nil
    }

    private static func parseISO8601Date(_ value: String?) -> Date? {
        guard let value, !value.isEmpty else { return nil }
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = formatter.date(from: value) { return date }
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.date(from: value)
    }

    private func deviceFingerprint() -> String? {
        if let existing = KeychainStore.string(forKey: Self.machineFingerprintKey), !existing.isEmpty {
            return existing
        }

        let value = UUID().uuidString.lowercased()
        return KeychainStore.set(value, forKey: Self.machineFingerprintKey) ? value : nil
    }
}

private enum KeychainStore {
    static func string(forKey key: String) -> String? {
        var query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    @discardableResult
    static func set(_ value: String, forKey key: String) -> Bool {
        let data = Data(value.utf8)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key
        ]
        let attributes: [String: Any] = [
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        let status = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if status == errSecItemNotFound {
            var insert = query
            attributes.forEach { insert[$0.key] = $0.value }
            return SecItemAdd(insert as CFDictionary, nil) == errSecSuccess
        }
        return status == errSecSuccess
    }

    static func delete(forKey key: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key
        ]
        SecItemDelete(query as CFDictionary)
    }
}
