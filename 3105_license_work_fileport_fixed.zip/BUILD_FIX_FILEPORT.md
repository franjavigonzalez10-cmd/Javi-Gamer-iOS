# Build fix: modern iOS SDK

- Replaced the unavailable `sys/fileport.h` include with a local compatibility header.
- The compatibility header declares the existing `fileport_t`, `fileport_makeport`, and `fileport_makefd` interfaces used by the project.
- Removed the hard-coded Xcode 16.4 selection from GitHub Actions; the runner now uses its installed/default Xcode and reports its version before building.
- The workflow is placed at the repository root under `.github/workflows/main.yml`.

This change addresses the `fatal error: 'sys/fileport.h' file not found` build failure shown by GitHub Actions.
